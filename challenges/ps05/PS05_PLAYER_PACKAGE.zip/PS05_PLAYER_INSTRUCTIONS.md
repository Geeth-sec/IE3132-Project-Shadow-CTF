# PS-05 - Suspicious Network Session

## CyberTrace: Project Shadow

### Scenario
Following the recovery of evidence from WS-23 in PS-04,
investigators identified suspicious network activity.

You have been provided with a synthetic network capture
from the Project Shadow incident.

### Provided Evidence
- shadow_traffic.pcapng
- capture_manifest.txt

### Objectives
1. Verify the network capture's integrity.
2. Identify the suspicious workstation.
3. Analyse DNS and TCP/HTTP traffic.
4. Locate the suspicious file transfer.
5. Recover the transferred archive.
6. Examine the HTTP response headers.
7. Investigate the recovered documents.
8. Reconstruct the Stage 5 flag.
9. Identify the clues required for PS-06.

### Flag Format
CyberTrace{S5_<FragmentA><FragmentB>}

### Recommended Tools
- Wireshark
- TShark
- unzip
- sha256sum

### Rules
- Do not modify the original capture.
- Recover evidence into a separate directory.
- Use only the provided synthetic evidence.
- Submit the reconstructed flag to the CTF platform.
