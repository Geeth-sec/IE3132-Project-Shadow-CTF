# PS-05 - Organiser Solution

## Challenge
CyberTrace Project Shadow - Suspicious Network Session

## Intended Solution

1. Verify shadow_traffic.pcapng using the SHA256
   checksum in capture_manifest.txt.

2. Open the capture using Wireshark or TShark.

3. Use the PS-04 evidence to identify:
   - Workstation: WS-23
   - Source IP: 10.10.4.23
   - Incident UTC: 2026-09-24 14:32:00

4. Inspect DNS traffic and locate:
   shadow-transfer.internal.local

5. Identify the suspicious HTTP session:
   10.10.4.23 -> 10.10.4.50

6. Examine the HTTP response header:
   X-CyberTrace-Fragment-A

7. Recover transfer_bundle.zip using:
   Wireshark > File > Export Objects > HTTP

8. Extract the ZIP and examine:
   - transfer_notes.txt
   - connection_note.txt

9. Recover Fragment B from transfer_notes.txt.

10. Reconstruct the Stage 5 flag:
    CyberTrace{S5_<FragmentA><FragmentB>}

11. Use connection_note.txt to identify
    the proposed PS-06 connection information.

## Verification

- Check the capture SHA256.
- Verify HTTP archive recovery.
- Compare recovered archive SHA256.
- Verify ZIP integrity.
- Confirm both flag fragments match the
  organiser's private configuration.

## Important

Do not distribute this solution to players.
Do not distribute private-values.txt.
Confirm the PS-06 server address and SSH port
before the final challenge release.
