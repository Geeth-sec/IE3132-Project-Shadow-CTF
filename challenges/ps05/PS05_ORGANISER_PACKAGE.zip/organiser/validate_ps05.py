from pathlib import Path
import hashlib
import re
import subprocess
import tempfile
import zipfile

PROJECT = Path.home() / "project-shadow-zoysa"
ROOT = PROJECT / "ps05-network"
CAPTURE = ROOT / "release/shadow_traffic.pcapng"
MANIFEST = ROOT / "release/capture_manifest.txt"
PRIVATE = PROJECT / "private/private-values.txt"

def load_config():
    config = {}
    for line in PRIVATE.read_text().splitlines():
        if "=" in line and not line.lstrip().startswith("#"):
            key, value = line.split("=", 1)
            config[key.strip()] = value.strip()
    return config

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def report(name, passed):
    print(f"{name}: {'PASS' if passed else 'FAIL'}")
    return passed

def main():
    config = load_config()
    results = []

    results.append(report(
        "PS05-F01 Capture exists",
        CAPTURE.is_file()
    ))

    if not CAPTURE.is_file():
        raise SystemExit(1)

    manifest = MANIFEST.read_text()
    results.append(report(
        "PS05-F02 SHA256 integrity",
        f"SHA256: {sha256(CAPTURE)}" in manifest
    ))

    response = subprocess.run(
        [
            "tshark", "-r", str(CAPTURE),
            "-Y", "http.response", "-V"
        ],
        capture_output=True,
        text=True,
        check=True
    ).stdout

    match_a = re.search(
        r"X-CyberTrace-Fragment-A:\s*([0-9a-f]{8})",
        response
    )
    a = match_a.group(1) if match_a else None

    results.append(report(
        "PS05-F03 HTTP Fragment A",
        a is not None and a == config.get("PS05_FRAGMENT_A")
    ))

    with tempfile.TemporaryDirectory() as temp:
        subprocess.run(
            [
                "tshark", "-r", str(CAPTURE),
                "--export-objects", f"http,{temp}",
                "-q"
            ],
            capture_output=True,
            check=True
        )

        archive = Path(temp) / "transfer_bundle.zip"
        exists = archive.is_file()

        results.append(report(
            "PS05-F04 Archive recovery",
            exists
        ))

        if not exists:
            raise SystemExit(1)

        original = ROOT / "build/transfer_bundle.zip"

        results.append(report(
            "PS05-F05 Archive SHA256",
            sha256(archive) == sha256(original)
        ))

        with zipfile.ZipFile(archive) as z:
            names = set(z.namelist())
            valid_zip = z.testzip() is None
            notes = z.read("transfer_notes.txt").decode()
            connection = z.read("connection_note.txt").decode()

        results.append(report(
            "PS05-F06 ZIP integrity",
            valid_zip
        ))

        results.append(report(
            "PS05-F07 Connection note",
            {"transfer_notes.txt", "connection_note.txt"}
            .issubset(names)
            and "Server address:" in connection
            and "SSH port:" in connection
            and config.get("PS06_ACCESS_PHRASE", "")
            in connection
        ))

        match_b = re.search(
            r"^FLAG_PART_B=([0-9a-f]{8})\s*$",
            notes, re.M
        )
        b = match_b.group(1) if match_b else None

        results.append(report(
            "PS05-F08 ZIP Fragment B",
            b is not None and b == config.get("PS05_FRAGMENT_B")
        ))

        flag = f"CyberTrace{{S5_{a}{b}}}"

        results.append(report(
            "PS05-F09 Final flag",
            bool(re.fullmatch(
                r"CyberTrace\{S5_[0-9a-f]{16}\}", flag
            ))
            and a == config.get("PS05_FRAGMENT_A")
            and b == config.get("PS05_FRAGMENT_B")
        ))

    passed = sum(results)
    print(f"\nFinal result: {passed}/{len(results)} PASS")
    print("Private flag and access phrase not displayed.")

    if not all(results):
        raise SystemExit(1)

if __name__ == "__main__":
    main()
