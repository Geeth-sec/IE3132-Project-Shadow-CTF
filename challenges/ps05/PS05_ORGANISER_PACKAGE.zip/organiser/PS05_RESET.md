# PS-05 - Reset Procedure

## Challenge Type
Static offline network-forensics challenge.

## Reset Method
The original PCAPNG is a read-only master artifact.
Players analyse their own copies.

## Reset Steps

1. Preserve the master shadow_traffic.pcapng.
2. Provide the participant with a fresh copy.
3. Remove only the participant's own temporary
   extracted files, with their permission.
4. Verify the replacement capture against the
   SHA256 recorded in capture_manifest.txt.
5. Allow the participant to restart the challenge.

## Player Recovery

If a participant gets stuck:
- Provide Hint 1 first.
- Provide Hint 2 if additional assistance is needed.
- Provide Hint 3 as the final hint.
- Reissue the original capture when necessary.

## Integrity and Security

- Never modify the master capture during testing.
- Do not expose the organiser solution.
- Do not expose private flag configuration.
- Keep the organiser and player packages separate.
