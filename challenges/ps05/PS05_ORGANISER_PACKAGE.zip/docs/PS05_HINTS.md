# PS-05 Player Hints

## Hint 1 - Easy
Use the workstation IP and incident timestamp
recovered during PS-04 to narrow your investigation.

## Hint 2 - Medium
Look for unusual DNS queries and HTTP requests.
Inspect HTTP response headers carefully.

## Hint 3 - Hard
An HTTP response contains a downloadable archive.
Use Wireshark's Export Objects feature to recover it.
Examine the transferred documents and combine the
two flag fragments in the required order.
